INSERT INTO `shopping_cart`.`order_details` (`Order_Id`, `Cust_Name`, `Phone_No`, `Address`, `Order_Date`, `Quantity`) VALUES ('1', 'Amith', '9673960407', 'Radhika Vihar', '2016-11-08', '3');
INSERT INTO `shopping_cart`.`order_details` (`Order_Id`, `Cust_Name`, `Phone_No`, `Address`, `Order_Date`, `Quantity`) VALUES ('2', 'Mona', '875451395', 'Rakshak Nagar', '2016-11-08', '3');
INSERT INTO `shopping_cart`.`order_details` (`Order_Id`, `Cust_Name`, `Phone_No`, `Address`, `Order_Date`, `Quantity`) VALUES ('3', 'Kavi', '7845127845', 'Rakshak Nagar Gold', '2016-11-08', '2');
INSERT INTO `shopping_cart`.`order_details` (`Order_Id`, `Cust_Name`, `Phone_No`, `Address`, `Order_Date`, `Quantity`) VALUES ('4', 'Monalisa', '784512788', 'Banglore', '2016-11-08', '3');
INSERT INTO `shopping_cart`.`order_details` (`Order_Id`, `Cust_Name`, `Phone_No`, `Address`, `Order_Date`, `Quantity`) VALUES ('5', 'Amol', '784575215', 'Wadganosheri', '2016-11-08', '3');
INSERT INTO `shopping_cart`.`order_details` (`Order_Id`, `Cust_Name`, `Phone_No`, `Address`, `Order_Date`, `Quantity`) VALUES ('6', 'Amit', '78521868', 'Banglore', '2016-11-08', '2');
select * from order_details;